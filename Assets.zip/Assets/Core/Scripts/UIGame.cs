using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIGame : Singleton<UIGame>
{

    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
