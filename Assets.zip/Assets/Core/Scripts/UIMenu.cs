using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIMenu : Singleton<UIMenu>
{

    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
